RETAIL BUSINESS PERFORMANCE & KPI ANALYSIS
==============================================
25 individual detailed PDF reports
7 CSV datasets
1 Excel workbook
5 supporting charts

Core modeled metrics:
Revenue: 97,588,425.92
Gross Profit: 19,385,288.96
Gross Margin: 19.86%
Orders: 114,421
AOV: 852.89
Records: 960

IMPORTANT: All data is SYNTHETIC/ILLUSTRATIVE. Do not present it as the actual financial performance of a real company.

Suggested LinkedIn project description:
Retail Business Performance & KPI Analysis | Business Management Portfolio Project
Built a 12-month retail performance model using a synthetic transaction dataset. Analyzed revenue, gross margin, store productivity, category mix, customer segmentation and omnichannel performance, then translated findings into a KPI dashboard, risk framework and strategic growth roadmap.
